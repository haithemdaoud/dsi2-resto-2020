<?php $__env->startSection('title', 'Welcome'); ?>

<?php $__env->startSection('content'); ?>
<main role="main">

    <section class="jumbotron text-center">
      <div class="container">
        <h1>DSI Restaurant</h1>
            <p class="lead text-muted">Our cooking is better than your mom's one! don't you believe? Just try it!</p>
            <p>
                <a href="#" class="btn btn-outline-primary my-2">Find a table</a>
                <a href="#" class="btn btn-outline-success my-2">You choose, we deliver!</a>
            </p>
      </div>
    </section>
  
    <div class="album py-5 bg-light">
      <div class="container">
  
        <div class="row">
            <?php $__currentLoopData = $meals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4">
                    <div class="card mb-4 shadow-sm">
                    <img src="<?php echo e($meal->photo); ?>" class="bd-placeholder-img card-img-top" width="100%" height="225" role="img" aria-label="Placeholder: Thumbnail">
                    <div class="card-body">
                        <h4 class="card-title"><?php echo e($meal->name); ?></h4>
                        <p class="card-text"><?php echo e($meal->description); ?></p>
                        <div class="d-flex justify-content-between align-items-center">
                        <div class="btn-group">
                            <button type="button" class="btn btn-sm btn-outline-secondary">View</button>
                            <button type="button" class="btn btn-sm btn-outline-secondary">Edit</button>
                        </div>
                        <small class="text-muted"><?php echo e($meal->sell_price); ?> $</small>
                        </div>
                    </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </div>
  
  </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\T470\Desktop\laravel\dsi2_2020\dsi21g1-restaurant\resources\views/welcome.blade.php ENDPATH**/ ?>